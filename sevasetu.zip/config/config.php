<?php
/**
 * The configuration for the framework
 *
 * @author Saurabh Badhwar
 */

define('DEVELOPMENT_ENVIRONMENT',true);
define('DB_NAME','sevasetu');
define('DB_USER','root');
define('DB_PASS','MYNET696');
define('DB_HOST','localhost');

//Email Config
define("EMAIL_HOST","localhost");

//Image Config
define("IMAGE_WIDTH",800);
define("IMAGE_HEIGHT",800);

//Domain Config
define("HOST","http://www.sevasetu.org/");