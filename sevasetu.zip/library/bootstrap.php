<?php
/**
 * The framework bootstrapper
 * Includes the required files for the proper functioning of the project
 *
 * @author Saurabh Badhwar
 */

require_once(ROOT.DS.'config'.DS.'config.php');
require_once(ROOT.DS.'library'.DS.'shared.php');
require_once(ROOT.DS.'library'.DS.'security.php');

