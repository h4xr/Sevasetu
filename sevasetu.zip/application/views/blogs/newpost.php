<form action="../blogs/save" method="POST">
    Post Name:<input type="text" name="post_name" /><br />
    Post Content:<textarea name="post_content"></textarea><br />
    Category:<input type="text" name="post_category" /><br />
    Status:<input type="text" name="post_status" /><br />
    <input type="submit" value="Post" />
</form>