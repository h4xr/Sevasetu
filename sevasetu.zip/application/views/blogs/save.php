<?php
    echo $message;
?>