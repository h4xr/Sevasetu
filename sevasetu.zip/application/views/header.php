<!DOCTYPE html>
    <html>
        <head>
            <title><?php echo $title; ?></title>
        </head>
    <body>