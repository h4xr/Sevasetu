<?php
 echo $message;
?>