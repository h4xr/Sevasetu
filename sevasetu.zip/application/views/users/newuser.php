<form action="../users/register" method="POST" enctype="multipart/form-data">
    name:<input type="text" name="name" /><br />
    username:<input type="text" name="username" /><br />
    password:<input type="password" name="password" /><br />
    password2:<input type="password" name="password2" /><br />
    Email:<input type="text" name="email" /><br />
    DOB:<input type="text" name="dob" /><br />
    Profile Picture: <input type="file" name="profile_picture" /><br />
    <input type="submit" value="Register" />
</form>