<?php

echo $message;
?>