<form action="../users/loginauth" method="POST">
    username:<input type="text" name="username" /><br />
    password:<input type="password" name="password" /><br />
    <input type="submit" value="Register" />
</form>