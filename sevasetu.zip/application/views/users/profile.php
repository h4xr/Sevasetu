<?php
    echo $user['users_name']."<br />";
    echo $user['users_username']."<br />";
    echo $user['users_email']."<br />";
    echo $user['users_dob']."<br />";
    echo $user['users_dor']."<br />";
?>