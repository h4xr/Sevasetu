<?php
echo $message;
?>